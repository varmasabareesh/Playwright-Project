const {test } = require("@playwright/test");
const POManager = require("../pages/POManager");

test('Automation of Project using page object model',async({page})=>{
    const username=`user_${Date.now()}`
    const password="sab_pass"
    const category="Phones"
    const product="Nokia lumia 1520"

    const pomanager=new POManager(page)

    const signup=pomanager.getSignupPage()
    await signup.goto()
    await signup.validSignup(username,password)

    const login=pomanager.getLoginPage()
    await login.goto()
    await login.validLogin(username,password)

    const dashboard=pomanager.getDashboard()
    await dashboard.selectProduct(category,product)

    const cart=pomanager.getCart()
    await cart.addToCart()
    await cart.openCart(product)
    await cart.placeOrder()

    const shippingDetails=pomanager.getShippingDetails()
    await shippingDetails.enterDetails("Test User","Germany","Berlin","4111111111111111","10","2026")
    await shippingDetails.purchase()

    const summary=pomanager.getSummary()
    await summary.verifyPurchase()
})
